﻿SafeAddString(AOCH_LANG, "de", 2)

SafeAddString(AOCH_InitMSG,              "[AOCH] Thanks for using Asquart's Ossein Cage Helper. Please send any issues on discord to asquart", 1)
SafeAddString(AOCH_OsiMSG,               "Please install |cff0000OdySupportIcons|r's latest version (optional dependency) to see all the addon features, including markers.", 1)

SafeAddString(AOCH_Tri1,                 "A Trifecta! Impressive!", 2)
SafeAddString(AOCH_Tri2,                 "Now how about...", 2)
SafeAddString(AOCH_Tri3,                 "... touch grass ?", 2)

SafeAddString(AOCH_CarrionShield,        "Aasschild", 2) -- id 232748
SafeAddString(AOCH_SpectralRevenant,     "spektraler Gebein-Wiedergänger", 2) -- id 126639
SafeAddString(AOCH_Abductor,             "entsetzlicher Entführer", 2) -- id 125740

SafeAddString(AOCH_GednaRelvel,          "Rothexe Gedna Relvel", 2) -- id 127021
SafeAddString(AOCH_TorturedRanyu,        "gequälter Ranyu", 2) -- id 126519
SafeAddString(AOCH_BloodDrkinerThisa,    "Bluttrinkerin Thisa", 2) -- id 126505

SafeAddString(AOCH_ShaperOfFlesh,        "Former des Fleisches", 2) -- id 125660
SafeAddString(AOCH_Fleshspawn,           "Fleischbrut", 2) -- id 128839
SafeAddString(AOCH_Channeler,            "Kanalisierer", 2) -- id 125666
SafeAddString(AOCH_Harvester,            "Ernterin", 2) -- id 125825
SafeAddString(AOCH_Daedroth,             "Daedroth", 2) -- id 125840

SafeAddString(AOCH_Jynorah,              "Jynorah", 2) -- id 126390
SafeAddString(AOCH_Skorknif,             "Skorkhif", 2) -- id 126391
SafeAddString(AOCH_Valneer,              "Glutgeschmiedeter Valneer", 2) -- id 125523
SafeAddString(AOCH_Myrinax,              "Funkensturm Myrinax", 2) -- id 125522

SafeAddString(AOCH_Kazpian,              "Oberunhold Kazpian", 2) -- id 125498
SafeAddString(AOCH_AgonizerBomb,         "Marterbombe", 2) -- id 128479