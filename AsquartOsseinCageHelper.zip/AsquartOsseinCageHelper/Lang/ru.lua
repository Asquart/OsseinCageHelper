﻿SafeAddString(AOCH_LANG, "ru", 5)

SafeAddString(AOCH_InitMSG,              "[AOCH] Thanks for using Asquart's Ossein Cage Helper. Please send any issues on discord to asquart", 1)
SafeAddString(AOCH_OsiMSG,               "Please install |cff0000OdySupportIcons|r's latest version (optional dependency) to see all the addon features, including markers.", 1)

SafeAddString(AOCH_Tri1,                 "Трифекта! Впечатляюще!", 5)
SafeAddString(AOCH_Tri2,                 "А как насчет...", 5)
SafeAddString(AOCH_Tri3,                 "... выйти на улицу ?", 5)

SafeAddString(AOCH_CarrionShield,        "Щит падальщиков", 5) -- id 232748
SafeAddString(AOCH_SpectralRevenant,     "Неупокоенный призрак Клетки", 5) -- id 126639
SafeAddString(AOCH_Abductor,             "Ужасный похититель", 5) -- id 125740

SafeAddString(AOCH_GednaRelvel,          "Красная ведьма Гедна Релвел", 5) -- id 127021
SafeAddString(AOCH_TorturedRanyu,        "Истерзанный Ранью", 5) -- id 126519
SafeAddString(AOCH_BloodDrkinerThisa,    "Кровопийца Тиза", 5) -- id 126505

SafeAddString(AOCH_ShaperOfFlesh,        "Формирователь плоти", 5) -- id 125660
SafeAddString(AOCH_Fleshspawn,           "Порождение плоти", 5) -- id 128839
SafeAddString(AOCH_Channeler,            "Проводник", 5) -- id 125666
SafeAddString(AOCH_Harvester,            "Жнец", 5) -- id 125825
SafeAddString(AOCH_Daedroth,             "Даэдрот", 5) -- id 125840

SafeAddString(AOCH_Jynorah,              "Джинора", 5) -- id 126390
SafeAddString(AOCH_Skorknif,             "Скоркиф", 5) -- id 126391
SafeAddString(AOCH_Valneer,              "Валнир Дитя Пламени", 5) -- id 125523
SafeAddString(AOCH_Myrinax,              "Мириназ Искра Бури", 5) -- id 125522

SafeAddString(AOCH_Kazpian,              "Сверхчудовище Казпиан", 5) -- id 125498
SafeAddString(AOCH_AgonizerBomb,         "Пыточная бомба", 5) -- id 128479