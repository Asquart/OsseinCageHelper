SafeAddString(AOCH_LANG, "jp", 6)

SafeAddString(AOCH_InitMSG,              "[AOCH] Thanks for using Asquart's Ossein Cage Helper. Please send any issues on discord to asquart", 1)
SafeAddString(AOCH_OsiMSG,               "Please install |cff0000OdySupportIcons|r's latest version (optional dependency) to see all the addon features, including markers.", 1)

SafeAddString(AOCH_Tri1,                 "A Trifecta! Impressive!", 6)
SafeAddString(AOCH_Tri2,                 "Now how about...", 6)
SafeAddString(AOCH_Tri3,                 "... touch grass ?", 6)

SafeAddString(AOCH_CarrionShield,        "腐肉の盾", 6) -- id 232748
SafeAddString(AOCH_SpectralRevenant,     "オステオンの形なきレブナント", 6) -- id 126639
SafeAddString(AOCH_Abductor,             "恐ろしき誘拐者", 6) -- id 125740

SafeAddString(AOCH_GednaRelvel,          "赤き魔女ゲドナ・レルヴェル", 6) -- id 127021
SafeAddString(AOCH_TorturedRanyu,        "苦しめられたラニュ", 6) -- id 126519
SafeAddString(AOCH_BloodDrkinerThisa,    "血を飲む者シサ", 6) -- id 126505

SafeAddString(AOCH_ShaperOfFlesh,        "肉の加工者", 6) -- id 125660
SafeAddString(AOCH_Fleshspawn,           "フレッシュスポーン", 6) -- id 128839
SafeAddString(AOCH_Channeler,            "チャネラー", 6) -- id 125666
SafeAddString(AOCH_Harvester,            "収穫者", 6) -- id 125825
SafeAddString(AOCH_Daedroth,             "デイドロス", 6) -- id 125840

SafeAddString(AOCH_Jynorah,              "ジノラー", 6) -- id 126390
SafeAddString(AOCH_Skorknif,             "スコルキフ", 6) -- id 126391
SafeAddString(AOCH_Valneer,              "ブレイズフォージド・ヴァルニア", 6) -- id 125523
SafeAddString(AOCH_Myrinax,              "スパークストーム・ミリナックス", 6) -- id 125522

SafeAddString(AOCH_Kazpian,              "オーバーフィーンド・カズピアン", 6) -- id 125498
SafeAddString(AOCH_AgonizerBomb,         "苦しめる者の爆弾", 6) -- id 128479